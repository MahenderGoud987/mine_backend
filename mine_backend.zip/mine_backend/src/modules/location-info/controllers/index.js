import getLocationInfo from "./getLocationInfo.js";

const locationInfoController = {};

locationInfoController.getLocationInfo = getLocationInfo;

export default locationInfoController;