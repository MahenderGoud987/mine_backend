import checkUpdateFromGithub from "./checkUpdate.js";

const updateController = {};

updateController.checkUpdateFromGithub = checkUpdateFromGithub;

export default updateController;